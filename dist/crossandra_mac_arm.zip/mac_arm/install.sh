mkdir -p ~/.crossandra
cp ./crss ~/.crossandra/crss
echo "\nexport PATH=\${PATH}:~/.crossandra\n" >> ~/.zprofile
source ~/.zprofile