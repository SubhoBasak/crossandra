mkdir -p ~/.crossandra
cp ./crss ~/.crossandra/crss
echo "\nexport PATH=\${PATH}:~/.crossandra\n" >> ~/.profile
source ~/.profile